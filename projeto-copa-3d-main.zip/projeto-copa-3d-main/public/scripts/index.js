import createCards from "./cards.js";

const btnGrupos = document.getElementById('btnGrupos');
const btnSelecoes = document.getElementById('btnSelecoes');
const main = document.getElementById('conteudo');


btnSelecoes.addEventListener('click', async (event) => {
    event.preventDefault();

    main.innerHTML = '';

    const section = createSection("Seleções");

    await createCards(section);

    main.appendChild(section);
});


function createSection(titulo) {

    const section = document.createElement('section');

    section.classList.add(
        'shadow-sm',
        'mx-auto',
        'w-full',
        'max-w-6xl',
        'pb-6'
    );

    section.innerHTML = `
        <div class="bg-nightblue p-3">
            <h2 class="font-bold text-icewhite text-xl text-center">
                ${titulo}
            </h2>
        </div>
    `;

    return section;
}


btnGrupos.addEventListener('click', async (event) => {

    event.preventDefault();

    main.innerHTML = '';

    try {

        const resposta = await fetch('/api/grupos');

        if (!resposta.ok) {
            throw new Error('Não foi possível carregar os grupos.');
        }

        const grupos = await resposta.json();

        const section = createSection("Grupos");


        const gruposContainer = document.createElement('div');

        gruposContainer.classList.add(
            'grid',
            'grid-cols-1',
            'sm:grid-cols-2',
            'lg:grid-cols-3',
            'xl:grid-cols-4',
            'gap-6',
            'p-6'
        );


        grupos.forEach(grupo => {

            const card = document.createElement('div');

            card.classList.add(
                'bg-white',
                'rounded-xl',
                'shadow-md',
                'border',
                'border-gray-200',
                'overflow-hidden',
                'transition',
                'duration-300',
                'hover:scale-105',
                'hover:shadow-xl'
            );


            card.innerHTML = `

                <!-- Título do grupo -->
                <div class="bg-nightblue text-icewhite p-3 text-center">

                    <h3 class="font-bold text-xl">
                        ${grupo.grupo}
                    </h3>

                </div>


                <!-- Seleções do grupo -->
                <div class="flex flex-col gap-3 p-4">

                    ${grupo.selecoes.map(selecao => `

                        <div class="flex items-center gap-3 p-2 rounded-lg
                                    bg-gray-100
                                    hover:bg-gray-200
                                    transition">

                            <img
                                class="w-10 h-10 object-cover rounded-full shadow-sm"
                                src="https://api.fifa.com/api/v3/picture/flags-sq-1/${selecao}"
                                alt="Bandeira ${selecao}"
                            >

                            <span class="font-bold text-lg">
                                ${selecao}
                            </span>

                        </div>

                    `).join('')}

                </div>

            `;

            gruposContainer.appendChild(card);

        });


        section.appendChild(gruposContainer);

        main.appendChild(section);

    } catch (error) {

        console.error(error);

        main.innerHTML = `
            <section class="max-w-6xl mx-auto p-6">

                <div class="bg-red-100 border-l-4 border-red-500
                            text-red-700 p-4 rounded">

                    <p class="font-bold">
                        Erro ao carregar os grupos.
                    </p>

                    <p>
                        ${error.message}
                    </p>

                </div>

            </section>
        `;
    }

});